# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: shop.spec.js >> TP-04 | Chicago 42 poveča količino in znesek ter ohrani druge postavke
- Location: e2e/tests/shop.spec.js:100:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByTestId('cart-item').filter({ has: getByRole('heading', { name: 'Air Jordan 1 Mid "Smoke Grey"', exact: true }) })
Timeout: 10000ms
- Expected  - 7
+ Received  + 1

- Air Jordan 1 Mid "Smoke Grey"
-
- Velikost: 42
-
- 125.00 €
-
- 1
+ Air Jordan 1 Mid "Smoke Grey"Velikost: 42125.00 €1

Call log:
  - Expect "toHaveText" getByTestId('cart-item').filter({ has: getByRole('heading', { name: 'Air Jordan 1 Mid "Smoke Grey"', exact: true }) }) with timeout 10000ms
  - waiting for getByTestId('cart-item').filter({ has: getByRole('heading', { name: 'Air Jordan 1 Mid "Smoke Grey"', exact: true }) })
    24 × locator resolved to <div data-testid="cart-item" class="flex items-center gap-4 p-4 border-t">…</div>
       - unexpected value "Air Jordan 1 Mid "Smoke Grey"Velikost: 42125.00 €1"

```

```yaml
- img "Air Jordan 1 Mid \"Smoke Grey\""
- heading "Air Jordan 1 Mid \"Smoke Grey\"" [level=3]
- paragraph: "Velikost: 42"
- paragraph: 125.00 €
- button:
  - img
- text: "1"
- button:
  - img
- button:
  - img
```

# Test source

```ts
  29  |   });
  30  | });
  31  | 
  32  | test('TP-01B | Zavrnitev napačnega gesla za preverjen račun R1', async ({ page, account, request }) => {
  33  |   await test.step('Uporabi pravi R1 in drugačno napačno geslo', async () => {
  34  |     expect(account.password).not.toBe('Napacno123!');
  35  |     await loginThroughUI(page, account, 'Napacno123!');
  36  |   });
  37  |   await test.step('Preveri obvestilo, URL in neprijavljeno stanje', async () => {
  38  |     await expect(page.getByRole('alert')).toHaveText('Napačen email ali geslo');
  39  |     await expect(page).toHaveURL('/login');
  40  |     const header = page.getByRole('banner');
  41  |     await expect(header.getByRole('link', { name: 'Prijava', exact: true })).toBeVisible();
  42  |     await expect(header.getByRole('link', { name: 'Naročila', exact: true })).toHaveCount(0);
  43  |     expect(await page.evaluate(() => localStorage.getItem('token'))).toBeNull();
  44  |     expect((await request.get('/api/orders')).status()).toBe(401);
  45  |   });
  46  | });
  47  | 
  48  | test('TP-02 | Registracija novega uporabnika in samodejna prijava', async ({ page, accounts, db }) => {
  49  |   const account = accounts.reserve('Test', 'Test123!');
  50  |   await test.step('Preveri novo e-pošto in odpri obrazec Registracija', async () => {
  51  |     const [existing] = await db.execute('SELECT id FROM users WHERE email = ?', [account.email]);
  52  |     expect(existing).toHaveLength(0);
  53  |     await page.goto('/');
  54  |     await page.getByRole('banner').getByRole('link', { name: 'Prijava', exact: true }).click();
  55  |     await page.getByRole('main').getByRole('link', { name: 'Registracija', exact: true }).click();
  56  |   });
  57  |   await test.step('Vnesi vse podatke in ustvari račun prek uporabniškega vmesnika', async () => {
  58  |     await page.getByLabel('Ime', { exact: true }).fill(account.firstName);
  59  |     await page.getByLabel('Priimek', { exact: true }).fill(account.lastName);
  60  |     await page.getByLabel('Email', { exact: true }).fill(account.email);
  61  |     await page.getByLabel('Geslo', { exact: true }).fill(account.password);
  62  |     await page.getByRole('button', { name: 'Registriraj se', exact: true }).click();
  63  |     await expectSignedIn(page, 'Test');
  64  |   });
  65  |   await test.step('Preveri shranjene podatke in prijavo po osvežitvi', async () => {
  66  |     const [users] = await db.execute('SELECT email, first_name, last_name FROM users WHERE email = ?', [account.email]);
  67  |     expect(users).toEqual([{ email: account.email, first_name: 'Test', last_name: 'Uporabnik' }]);
  68  |     await page.reload();
  69  |     await expectSignedIn(page, 'Test');
  70  |   });
  71  | });
  72  | 
  73  | test('TP-03 | Low Top prikaže pravilne modele in Vsi izdelki obnovi katalog', async ({ page, request }) => {
  74  |   await test.step('Preveri predpogoje kataloga in zabeleži začetni seznam', async () => {
  75  |     const response = await request.get('/api/products');
  76  |     expect(response.status()).toBe(200);
  77  |     const products = await response.json();
  78  |     expect(products.map(p => p.name).sort()).toEqual(seedProducts.map(p => p.name).sort());
  79  |     await page.goto('/');
  80  |     await page.getByRole('banner').getByRole('link', { name: 'Izdelki', exact: true }).click();
  81  |     await page.getByRole('button', { name: 'Vsi izdelki', exact: true }).click();
  82  |     await expect(page.getByTestId('product-card')).toHaveCount(8);
  83  |   });
  84  |   const headings = page.getByTestId('product-card').getByRole('heading', { level: 3 });
  85  |   const originalNames = await headings.allTextContents();
  86  |   expect([...originalNames].sort()).toEqual(seedProducts.map(p => p.name).sort());
  87  |   await test.step('Preveri vse nazive Low Top in odsotnost High Top ter Mid Top', async () => {
  88  |     await page.getByRole('button', { name: 'Low Top', exact: true }).click();
  89  |     await expect(headings).toHaveText([tripleWhite]);
  90  |     await expect(headings.filter({ hasText: /High|Mid/ })).toHaveCount(0);
  91  |     await expect(page.getByText('Prikazanih 1 od 8 izdelkov', { exact: true })).toBeVisible();
  92  |   });
  93  |   await test.step('Obnovi in primerjaj celoten katalog', async () => {
  94  |     await page.getByRole('button', { name: 'Vsi izdelki', exact: true }).click();
  95  |     await expect(headings).toHaveText(originalNames);
  96  |     await expect(page.getByText('Prikazanih 8 od 8 izdelkov', { exact: true })).toBeVisible();
  97  |   });
  98  | });
  99  | 
  100 | test('TP-04 | Chicago 42 poveča količino in znesek ter ohrani druge postavke', async ({ page, request }) => {
  101 |   const products = await (await request.get('/api/products')).json();
  102 |   const product = products.find(p => p.name === chicago);
  103 |   expect(Number(product.price)).toBe(180);
  104 |   const detail = await (await request.get(`/api/products/${product.id}`)).json();
  105 |   expect(detail.sizes.find(s => s.size === '42').stock).toBeGreaterThan(0);
  106 |   await test.step('Začetek s prazno košarico: Chicago 42, količina 1, skupaj 180 €', async () => {
  107 |     await page.goto('/cart');
  108 |     await expect(page.getByRole('heading', { name: 'Vaša košarica je prazna' })).toBeVisible();
  109 |     await addProduct(page, chicago);
  110 |     await expect(cartItem(page, chicago).getByText('Velikost: 42', { exact: true })).toBeVisible();
  111 |     await expect(cartItem(page, chicago).getByTestId('cart-quantity')).toHaveText('1');
  112 |     await expect(cartItem(page, chicago).getByText('180.00 €', { exact: true })).toBeVisible();
  113 |     await expect(page.getByTestId('cart-total')).toHaveText('180.00 €');
  114 |     await expect(page.getByTestId('cart-item')).toHaveCount(1);
  115 |   });
  116 |   await test.step('Pripravi znano začetno stanje q0 = 1, S0 = 305 € in drugo postavko', async () => {
  117 |     await addProduct(page, smokeGrey);
  118 |     await expect(page.getByTestId('cart-item')).toHaveCount(2);
  119 |     await expect(page.getByTestId('cart-total')).toHaveText('305.00 €');
  120 |     await expect(cartItem(page, smokeGrey).getByTestId('cart-quantity')).toHaveText('1');
  121 |   });
  122 |   const otherItemBefore = await cartItem(page, smokeGrey).innerText();
  123 |   await test.step('Ponovno dodaj Chicago 42 in preveri q0 + 1 ter S0 + 180 €', async () => {
  124 |     await addProduct(page, chicago);
  125 |     await expect(cartItem(page, chicago).getByTestId('cart-quantity')).toHaveText('2');
  126 |     await expect(cartItem(page, chicago).getByText('Velikost: 42', { exact: true })).toBeVisible();
  127 |     await expect(page.getByTestId('cart-total')).toHaveText('485.00 €');
  128 |     await expect(page.getByTestId('cart-item')).toHaveCount(2);
> 129 |     await expect(cartItem(page, smokeGrey)).toHaveText(otherItemBefore);
      |                                             ^ Error: expect(locator).toHaveText(expected) failed
  130 |     await expect(page.getByRole('button', { name: 'Prijava za nadaljevanje' })).toBeVisible();
  131 |   });
  132 | });
  133 | 
  134 | test('TP-05 | Oddaja naročila shrani prave podatke in izprazni košarico', async ({ page, account, request, db }, testInfo) => {
  135 |   const headers = { Authorization: `Bearer ${account.token}` };
  136 |   const before = await (await request.get('/api/orders', { headers })).json();
  137 |   await test.step('Neodvisno pripravi prijavo in točno en Chicago 42 za 180 €', async () => {
  138 |     await loginThroughUI(page, account);
  139 |     await expectSignedIn(page, 'Testni');
  140 |     await page.getByRole('banner').getByRole('link', { name: 'Košarica', exact: true }).click();
  141 |     await expect(page.getByRole('heading', { name: 'Vaša košarica je prazna' })).toBeVisible();
  142 |     await addProduct(page, chicago);
  143 |     await expect(cartItem(page, chicago).getByTestId('cart-quantity')).toHaveText('1');
  144 |     await expect(page.getByTestId('cart-total')).toHaveText('180.00 €');
  145 |   });
  146 |   await test.step('Odpri blagajno, vnesi dostavo in preveri povzetek', async () => {
  147 |     await page.getByRole('button', { name: 'Nadaljuj na blagajno', exact: true }).click();
  148 |     await expect(page.getByRole('heading', { name: 'Blagajna', exact: true })).toBeVisible();
  149 |     await page.getByLabel('Naslov', { exact: true }).fill('Testna ulica 10');
  150 |     await page.getByLabel('Mesto', { exact: true }).fill('Maribor');
  151 |     await page.getByLabel('Poštna številka', { exact: true }).fill('2000');
  152 |     await expect(page.getByText(`${chicago} (Vel. 42) x1`, { exact: true })).toBeVisible();
  153 |     await expect(page.getByTestId('checkout-total')).toHaveText('180.00 €');
  154 |   });
  155 |   let orderId;
  156 |   await test.step('Oddaj naročilo in preveri ter potrdi obvestilo', async () => {
  157 |     const responsePromise = page.waitForResponse(r => r.url().endsWith('/api/orders') && r.request().method() === 'POST');
  158 |     const dialogPromise = page.waitForEvent('dialog');
  159 |     const clickPromise = page.getByRole('button', { name: 'Potrdi naročilo', exact: true }).click();
  160 |     const dialog = await dialogPromise;
  161 |     const message = dialog.message();
  162 |     await dialog.accept();
  163 |     await clickPromise;
  164 |     expect(message).toBe('Naročilo uspešno oddano!');
  165 |     const response = await responsePromise;
  166 |     expect(response.status()).toBe(201);
  167 |     const result = await response.json();
  168 |     orderId = result.orderId;
  169 |     expect(before.map(o => o.id)).not.toContain(orderId);
  170 |     expect(Number(result.totalAmount)).toBe(180);
  171 |     expect(response.request().postDataJSON()).toMatchObject({
  172 |       shippingAddress: 'Testna ulica 10', shippingCity: 'Maribor', shippingPostalCode: '2000',
  173 |       items: [expect.objectContaining({ size: '42', quantity: 1 })],
  174 |     });
  175 |   });
  176 |   const order = page.getByTestId('order-card').filter({ hasText: `Naročilo #${orderId}` });
  177 |   await test.step('Preveri novo naročilo in ohranitev istega zapisa po osvežitvi', async () => {
  178 |     await expect(page.getByRole('heading', { name: 'Moja naročila', exact: true })).toBeVisible();
  179 |     for (const refresh of [false, true]) {
  180 |       if (refresh) await page.reload();
  181 |       await expect(order).toHaveCount(1);
  182 |       await expect(order.getByText(chicago, { exact: true })).toBeVisible();
  183 |       await expect(order.getByText('Vel. 42 x1', { exact: true })).toBeVisible();
  184 |       await expect(order.getByTestId('order-total')).toHaveText('180.00 €');
  185 |       await expect(order.getByText('V čakanju', { exact: true })).toBeVisible();
  186 |     }
  187 |     const [stored] = await db.execute('SELECT user_id, total_amount, shipping_address, shipping_city, shipping_postal_code, status FROM orders WHERE id = ?', [orderId]);
  188 |     expect(stored).toEqual([{
  189 |       user_id: account.user.id, total_amount: '180.00', shipping_address: 'Testna ulica 10',
  190 |       shipping_city: 'Maribor', shipping_postal_code: '2000', status: 'pending',
  191 |     }]);
  192 |     const after = await (await request.get('/api/orders', { headers })).json();
  193 |     expect(after).toHaveLength(before.length + 1);
  194 |     await testInfo.attach('shranjeno-narocilo.json', { body: Buffer.from(JSON.stringify({ orderId, ...stored[0] }, null, 2)), contentType: 'application/json' });
  195 |   });
  196 |   await test.step('Preveri prazno košarico tudi po osvežitvi', async () => {
  197 |     await page.getByRole('banner').getByRole('link', { name: 'Košarica', exact: true }).click();
  198 |     await expect(page.getByRole('heading', { name: 'Vaša košarica je prazna' })).toBeVisible();
  199 |     await expect(page.getByTestId('cart-item')).toHaveCount(0);
  200 |     await page.reload();
  201 |     await expect(page.getByRole('heading', { name: 'Vaša košarica je prazna' })).toBeVisible();
  202 |   });
  203 | });
  204 | 
```